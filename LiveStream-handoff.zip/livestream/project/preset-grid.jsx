// Data for the preset grid
const PRESETS = {
  Speaker: [
    { n: 1, label: "Lecturn",  scene: "speakerLectern" },
    { n: 1, label: "Wide",     scene: "speakerWide" },
    { n: 2, label: "Left",     scene: "speakerLeft" },
    { n: 3, label: "Right",    scene: "speakerRight" },
  ],
  Piano: [
    { n: 1, label: "Wide",     scene: "pianoWide" },
    { n: 1, label: "Left",     scene: "pianoLeft" },
    { n: 2, label: "Front",    scene: "pianoFront" },
    { n: 2, label: "Back",     scene: "pianoBack" },
    { n: 3, label: "Keys",     scene: "pianoFront" },
    { n: 3, label: "Side",     scene: "pianoLeft" },
    { n: 4, label: "Over",     scene: "pianoWide" },
    { n: 4, label: "Detail",   scene: "pianoBack" },
  ],
  Piano2: [ // second piano column from reference
    { n: 1, label: "Preset",   scene: "pianoFront" },
    { n: 2, label: "Preset",   scene: "pianoWide" },
    { n: 2, label: "Preset",   scene: "pianoBack" },
    { n: 2, label: "Preset",   scene: "pianoLeft" },
  ],
  Singers: [
    { n: 1, label: "Front",    scene: "singersFront" },
    { n: 2, label: "Piano",    scene: "singersKeys" },
    { n: 2, label: "Left",     scene: "singersLeft" },
    { n: 1, label: "Wide",     scene: "singersWide" },
  ],
  Congregation: [
    { n: 1, label: "Right",    scene: "congRight",  live: true },
    { n: 2, label: "Left",     scene: "congLeft" },
    { n: 1, label: "Front",    scene: "congFront" },
    { n: 1, label: "Custom",   scene: "congBack" },
  ],
  Custom: [
    { n: 1, label: "Custom 1", scene: "custom1" },
    { n: 2, label: "Custom 2", scene: "custom2" },
    { n: 2, label: "Custom 3", scene: "custom3" },
    { n: 2, label: "Custom 4", scene: "custom4" },
  ],
};

const AUTO_QUEUE = [
  { n: 1, label: "Lecturn · Speaker", scene: "qA", t: 40 },
  { n: 2, label: "Wide · Piano",      scene: "qB", t: 25 },
  { n: 1, label: "Piano · Keys",      scene: "qB", t: 18 },
  { n: 2, label: "Choir · Front",     scene: "qC", t: 12 },
  { n: 1, label: "Congregation",      scene: "qD", t: 30 },
  { n: 2, label: "Lecturn · Speaker", scene: "qA", t: 20 },
  { n: 1, label: "Singers · Wide",    scene: "qC", t: 15 },
  { n: 2, label: "Cong · Back",       scene: "qD", t: 22 },
];

function ThumbCard({ preset, onAir, selected, compact, onClick, queueBadge }) {
  return (
    <button
      className={"thumb" + (onAir ? " onair" : "") + (selected ? " selected" : "") + (compact ? " compact" : "")}
      onClick={onClick}
    >
      <div className="thumb-img">
        <Thumb scene={preset.scene}/>
        {onAir && <span className="thumb-livebadge">LIVE</span>}
        {queueBadge != null && <span className="thumb-timer">{queueBadge}s</span>}
      </div>
      <div className="thumb-meta">
        <span className={"thumb-num" + (onAir ? " num-live" : "")}>{preset.n}</span>
        <span className="thumb-label">{preset.label}</span>
      </div>
    </button>
  );
}

function PresetColumn({ title, presets, colIndex, liveId, setLive, span = 1, innerCols }) {
  const cols = innerCols || span;
  return (
    <div className="pcol" style={{ gridColumn: `span ${span}` }}>
      <div className="pcol-head">
        <span className="pcol-title">{title}</span>
      </div>
      <div className="pcol-grid" data-cols={cols} style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
        {presets.map((p, i) => {
          const id = `${colIndex}-${i}`;
          return (
            <ThumbCard
              key={id}
              preset={p}
              onAir={liveId === id}
              onClick={() => setLive(id)}
            />
          );
        })}
      </div>
    </div>
  );
}

function AutoQueueColumn({ items, running, setRunning, liveIdx, advance }) {
  return (
    <div className="pcol pcol-queue" style={{ gridColumn: "span 2" }}>
      <div className="pcol-head pcol-head-queue">
        <span className="pcol-title">Auto Queue</span>
        <div className="queue-actions">
          <button className={"qbtn" + (running ? " on" : "")} onClick={() => setRunning(r => !r)}>
            <Icon name={running ? "pause" : "play"} size={12}/>
            <span>{running ? "Running" : "Paused"}</span>
          </button>
          <button className="qbtn" onClick={advance}><Icon name="swap" size={12}/><span>Skip</span></button>
        </div>
      </div>
      <div className="pcol-grid" data-cols="2" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
        {items.map((p, i) => (
          <ThumbCard
            key={i}
            preset={p}
            onAir={i === liveIdx}
            selected={i === (liveIdx + 1) % items.length}
            queueBadge={p.t}
            onClick={() => {}}
          />
        ))}
      </div>
    </div>
  );
}

function PresetGrid({ liveId, setLive, queueRunning, setQueueRunning, queueIdx, advanceQueue, showCustom }) {
  return (
    <div className="preset-grid">
      <PresetColumn title="Speaker"      colIndex="speaker" presets={PRESETS.Speaker}      liveId={liveId} setLive={setLive} span={1} innerCols={1} />
      <PresetColumn title="Piano"        colIndex="piano"   presets={PRESETS.Piano}        liveId={liveId} setLive={setLive} span={2} innerCols={2} />
      <PresetColumn title="Singers"      colIndex="singers" presets={PRESETS.Singers}      liveId={liveId} setLive={setLive} />
      <PresetColumn title="Congregation" colIndex="cong"    presets={PRESETS.Congregation} liveId={liveId} setLive={setLive} />
      {showCustom && <PresetColumn title="Custom" colIndex="custom" presets={PRESETS.Custom} liveId={liveId} setLive={setLive} />}
      <AutoQueueColumn
        items={AUTO_QUEUE}
        running={queueRunning}
        setRunning={setQueueRunning}
        liveIdx={queueIdx}
        advance={advanceQueue}
      />
    </div>
  );
}

Object.assign(window, { PresetGrid });
