// Procedural thumbnail placeholders for camera presets.
// Uses deterministic SVG "scenes" — subtle striped backgrounds with
// schematic shapes (pew rows, lectern blocks, piano silhouette).
// Each thumb takes a `scene` string key.

const SCENES = {
  // SPEAKER
  speakerLectern: { bg: "#2a1f1c", tone: "#3a2a24", shapes: "lectern" },
  speakerWide:    { bg: "#2a1f1c", tone: "#3a2a24", shapes: "stageWide" },
  speakerLeft:    { bg: "#2a1f1c", tone: "#3a2a24", shapes: "figureLeft" },
  speakerRight:   { bg: "#2a1f1c", tone: "#3a2a24", shapes: "figureRight" },
  // PIANO
  pianoWide:      { bg: "#241a17", tone: "#34241e", shapes: "pianoWide" },
  pianoLeft:      { bg: "#241a17", tone: "#34241e", shapes: "pianoLeft" },
  pianoFront:     { bg: "#241a17", tone: "#34241e", shapes: "pianoFront" },
  pianoBack:      { bg: "#241a17", tone: "#34241e", shapes: "pianoBack" },
  // SINGERS
  singersFront:   { bg: "#2a2220", tone: "#3a302c", shapes: "choir" },
  singersKeys:    { bg: "#2a2220", tone: "#3a302c", shapes: "pianoFront" },
  singersLeft:    { bg: "#2a2220", tone: "#3a302c", shapes: "figureLeft" },
  singersWide:    { bg: "#2a2220", tone: "#3a302c", shapes: "stageWide" },
  // CONGREGATION
  congRight:      { bg: "#1d1814", tone: "#2a221c", shapes: "pewsRight" },
  congLeft:       { bg: "#1d1814", tone: "#2a221c", shapes: "pewsLeft" },
  congFront:      { bg: "#1d1814", tone: "#2a221c", shapes: "pewsFront" },
  congBack:       { bg: "#1d1814", tone: "#2a221c", shapes: "pewsBack" },
  // CUSTOM
  custom1:        { bg: "#1a1a1f", tone: "#26262c", shapes: "stageWide" },
  custom2:        { bg: "#1a1a1f", tone: "#26262c", shapes: "choir" },
  custom3:        { bg: "#1a1a1f", tone: "#26262c", shapes: "lectern" },
  custom4:        { bg: "#1a1a1f", tone: "#26262c", shapes: "pianoWide" },
  // AUTO QUEUE (reuse)
  qA: { bg: "#2a1f1c", tone: "#3a2a24", shapes: "lectern" },
  qB: { bg: "#241a17", tone: "#34241e", shapes: "pianoWide" },
  qC: { bg: "#2a2220", tone: "#3a302c", shapes: "choir" },
  qD: { bg: "#1d1814", tone: "#2a221c", shapes: "pewsFront" },
  // LIVE CAMS
  camBack:  { bg: "#1a1614", tone: "#2a211c", shapes: "pewsBack" },
  camLeft:  { bg: "#1a1614", tone: "#2a211c", shapes: "pewsLeft" },
  camRight: { bg: "#1a1614", tone: "#2a211c", shapes: "pewsRight" },
  // Data projection (colorbars)
  colorbars: { bg: "#000", tone: "#000", shapes: "colorbars" },
};

function Shapes({ kind, w, h }) {
  const s = { stroke: "rgba(0,0,0,0.35)", strokeWidth: 1, vectorEffect: "non-scaling-stroke" };
  switch (kind) {
    case "lectern":
      return (
        <g>
          {/* back wall */}
          <rect x="0" y={h*0.15} width={w} height={h*0.55} fill="rgba(255,255,255,0.03)" />
          {/* cross/window hint */}
          <rect x={w*0.46} y={h*0.2} width={w*0.02} height={h*0.35} fill="rgba(255,255,255,0.08)" />
          <rect x={w*0.4} y={h*0.3} width={w*0.14} height={h*0.02} fill="rgba(255,255,255,0.08)" />
          {/* lectern box */}
          <rect x={w*0.42} y={h*0.6} width={w*0.16} height={h*0.25} fill="#1a110e" {...s} />
          {/* floor */}
          <rect x="0" y={h*0.82} width={w} height={h*0.18} fill="rgba(0,0,0,0.35)" />
        </g>
      );
    case "stageWide":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.6} fill="rgba(255,255,255,0.025)" />
          <rect x={w*0.48} y={h*0.18} width={w*0.015} height={h*0.3} fill="rgba(255,255,255,0.06)" />
          <rect x={w*0.44} y={h*0.25} width={w*0.1} height={h*0.015} fill="rgba(255,255,255,0.06)" />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.3)" />
        </g>
      );
    case "figureLeft":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.6} fill="rgba(255,255,255,0.025)" />
          <ellipse cx={w*0.38} cy={h*0.35} rx={w*0.05} ry={h*0.08} fill="#e8d4c0" opacity="0.5" />
          <rect x={w*0.33} y={h*0.43} width={w*0.1} height={h*0.25} fill="#3a2e28" />
          <rect x={w*0.34} y={h*0.45} width={w*0.02} height={h*0.3} fill="#111" />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.3)" />
        </g>
      );
    case "figureRight":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.6} fill="rgba(255,255,255,0.025)" />
          <ellipse cx={w*0.2} cy={h*0.4} rx={w*0.04} ry={h*0.07} fill="#e8d4c0" opacity="0.4" />
          <rect x={w*0.16} y={h*0.47} width={w*0.08} height={h*0.23} fill="#3a2e28" />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.3)" />
        </g>
      );
    case "pianoWide":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.55} fill="rgba(255,255,255,0.025)" />
          {/* piano body */}
          <rect x={w*0.25} y={h*0.5} width={w*0.5} height={h*0.22} fill="#0d0a09" {...s} />
          <rect x={w*0.28} y={h*0.53} width={w*0.44} height={h*0.04} fill="#f4f1ec" opacity="0.8" />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.35)" />
        </g>
      );
    case "pianoLeft":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.55} fill="rgba(255,255,255,0.025)" />
          <rect x={w*0.05} y={h*0.5} width={w*0.5} height={h*0.22} fill="#0d0a09" {...s} />
          <rect x={w*0.08} y={h*0.53} width={w*0.44} height={h*0.04} fill="#f4f1ec" opacity="0.8" />
          <ellipse cx={w*0.3} cy={h*0.38} rx={w*0.05} ry={h*0.08} fill="#e8d4c0" opacity="0.4" />
          <rect x={w*0.25} y={h*0.45} width={w*0.1} height={h*0.12} fill="#3a2e28" />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.35)" />
        </g>
      );
    case "pianoFront":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.6} fill="rgba(255,255,255,0.025)" />
          {/* keys */}
          <rect x={w*0.15} y={h*0.55} width={w*0.7} height={h*0.12} fill="#f4f1ec" opacity="0.85" />
          {[0,1,2,3,4,5,6,7,8,9,10,11,12].map(i => (
            <rect key={i} x={w*0.15 + i*w*0.054} y={h*0.55} width={1} height={h*0.12} fill="#111" />
          ))}
          {[0,1,3,4,5,7,8,10,11].map((i, k) => (
            <rect key={k} x={w*0.15 + i*w*0.054 + w*0.035} y={h*0.55} width={w*0.025} height={h*0.07} fill="#111" />
          ))}
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.35)" />
        </g>
      );
    case "pianoBack":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.55} fill="rgba(255,255,255,0.025)" />
          <rect x={w*0.2} y={h*0.45} width={w*0.6} height={h*0.28} fill="#0d0a09" {...s} />
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.35)" />
        </g>
      );
    case "choir":
      return (
        <g>
          <rect x="0" y={h*0.1} width={w} height={h*0.6} fill="rgba(255,255,255,0.025)" />
          {[0,1,2,3,4].map(i => (
            <g key={i}>
              <ellipse cx={w*(0.15 + i*0.175)} cy={h*0.32} rx={w*0.035} ry={h*0.06} fill="#e8d4c0" opacity="0.45" />
              <rect x={w*(0.11 + i*0.175)} y={h*0.4} width={w*0.08} height={h*0.28} fill="#2a2420" />
            </g>
          ))}
          <rect x="0" y={h*0.72} width={w} height={h*0.28} fill="rgba(0,0,0,0.3)" />
        </g>
      );
    case "pewsFront":
      return (
        <g>
          {[0.3, 0.45, 0.6, 0.75, 0.9].map((y, i) => (
            <rect key={i} x={w*0.05} y={h*y} width={w*0.9} height={h*0.04} fill="#3a2a1e" opacity={0.3 + i*0.1} {...s} />
          ))}
          <rect x={w*0.47} y="0" width={w*0.06} height={h*0.3} fill="rgba(255,255,255,0.04)" />
        </g>
      );
    case "pewsBack":
      return (
        <g>
          {[0.25, 0.4, 0.55, 0.7, 0.85].map((y, i) => (
            <rect key={i} x={w*(0.1 - i*0.02)} y={h*y} width={w*(0.8 + i*0.04)} height={h*0.035} fill="#3a2a1e" opacity={0.25 + i*0.1} {...s} />
          ))}
        </g>
      );
    case "pewsLeft":
      return (
        <g>
          {[0.35, 0.5, 0.65, 0.8].map((y, i) => (
            <rect key={i} x={w*0.05} y={h*y} width={w*0.55} height={h*0.04} fill="#3a2a1e" opacity={0.3 + i*0.1} transform={`skewX(-10)`} {...s} />
          ))}
          <rect x={w*0.65} y={h*0.1} width={w*0.3} height={h*0.6} fill="rgba(255,255,255,0.025)" />
        </g>
      );
    case "pewsRight":
      return (
        <g>
          {[0.35, 0.5, 0.65, 0.8].map((y, i) => (
            <rect key={i} x={w*0.4} y={h*y} width={w*0.55} height={h*0.04} fill="#3a2a1e" opacity={0.3 + i*0.1} {...s} />
          ))}
          <rect x="0" y={h*0.1} width={w*0.3} height={h*0.6} fill="rgba(255,255,255,0.025)" />
        </g>
      );
    case "colorbars": {
      const colors = ["#c0c0c0", "#c0c000", "#00c0c0", "#00c000", "#c000c0", "#c00000", "#0000c0", "#000"];
      return (
        <g>
          {colors.map((c, i) => (
            <rect key={i} x={w*(i/colors.length)} y="0" width={w/colors.length + 0.5} height={h} fill={c} />
          ))}
        </g>
      );
    }
    default:
      return null;
  }
}

function Thumb({ scene = "lectern", className = "", style }) {
  const cfg = SCENES[scene] || SCENES.speakerLectern;
  // viewBox uses 160x90 (16:9)
  const w = 160, h = 90;
  return (
    <svg className={className} style={style} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id={`stripe-${scene}`} patternUnits="userSpaceOnUse" width="3" height="3" patternTransform="rotate(45)">
          <rect width="3" height="3" fill={cfg.bg} />
          <rect width="1" height="3" fill={cfg.tone} />
        </pattern>
        <linearGradient id={`vig-${scene}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="rgba(0,0,0,0)" />
          <stop offset="1" stopColor="rgba(0,0,0,0.4)" />
        </linearGradient>
      </defs>
      <rect width={w} height={h} fill={`url(#stripe-${scene})`} />
      <Shapes kind={cfg.shapes} w={w} h={h} />
      <rect width={w} height={h} fill={`url(#vig-${scene})`} />
    </svg>
  );
}

window.Thumb = Thumb;
