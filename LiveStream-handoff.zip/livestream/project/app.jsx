// LiveStream — main app shell
const { useState, useEffect, useMemo } = React;

const DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentHue": 142,
  "density": "comfortable",
  "showCustomColumn": true,
  "showCueList": true,
  "tallyGlow": true
}/*EDITMODE-END*/;

function App() {
  const [values, setKey] = useTweaks(DEFAULTS);

  const [rail, setRail] = useState({
    spots: true, stage: true, front: false,
    tvLeft: true, tvRight: true,
    audio: "video",
    recording: true, streaming: true,
    ptzSpeed: 6,
  });

  const [liveId, setLive] = useState("speaker-0"); // current preset LIVE
  const [liveCamId, setLiveCam] = useState("right"); // current live camera
  const [queueRunning, setQueueRunning] = useState(true);
  const [queueIdx, setQueueIdx] = useState(0);
  const [cueIdx, setCueIdx] = useState(4); // "Sermon"
  const [showLegend, setShowLegend] = useState(false);

  // Apply tweak CSS
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--live', `oklch(0.72 0.19 ${values.accentHue})`);
    root.style.setProperty('--live-dim', `oklch(0.72 0.19 ${values.accentHue} / 0.18)`);
  }, [values.accentHue]);

  useEffect(() => {
    document.body.dataset.density = values.density;
  }, [values.density]);

  const advanceQueue = () => setQueueIdx(i => (i + 1) % 6);

  // Esc closes legend
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") setShowLegend(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="app">
      <LeftRail state={rail} setState={setRail} onEmergency={() => alert("Emergency cut triggered")} />
      <TopBar cueIdx={cueIdx} setCueIdx={setCueIdx} showLegend={showLegend} setShowLegend={setShowLegend} />
      <main className="main">
        <PresetGrid
          liveId={liveId}
          setLive={setLive}
          queueRunning={queueRunning}
          setQueueRunning={setQueueRunning}
          queueIdx={queueIdx}
          advanceQueue={advanceQueue}
          showCustom={values.showCustomColumn}
        />
        <LiveFeedRow
          liveCamId={liveCamId}
          setLiveCam={setLiveCam}
          overlays={{}}
          setOverlays={() => {}}
          onTake={() => {}}
        />
      </main>

      {showLegend && <ShortcutLegend onClose={() => setShowLegend(false)} />}

      <TweaksPanel title="Tweaks">
        <TweakSection title="Accent (LIVE tally)">
          <TweakSlider label="Hue" min={0} max={360} step={1} value={values.accentHue} onChange={v => setKey('accentHue', v)} />
          <div style={{display:'flex',gap:6,flexWrap:'wrap',marginTop:4}}>
            {[142, 200, 24, 10, 280, 50].map(h => (
              <button key={h} onClick={() => setKey('accentHue', h)}
                style={{width:22,height:22,borderRadius:4,border:'1px solid #333',background:`oklch(0.72 0.19 ${h})`,cursor:'pointer',padding:0}}/>
            ))}
          </div>
        </TweakSection>
        <TweakSection title="Layout">
          <TweakRadio label="Density" value={values.density} options={["comfortable","compact"]} onChange={v => setKey('density', v)} />
          <TweakToggle label="Show Custom column" value={values.showCustomColumn} onChange={v => setKey('showCustomColumn', v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
