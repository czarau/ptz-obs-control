// Bottom row: live feeds (4), plus right-side dock with meters + health + cues
function LiveFeedRow({ liveCamId, setLiveCam, overlays, setOverlays, onTake }) {
  const cams = [
    { id: "back",  label: "Camera Back",   scene: "camBack",  hint: "PTZ · Back gallery" },
    { id: "left",  label: "Camera Left",   scene: "camLeft",  hint: "PTZ · Stage left" },
    { id: "right", label: "Camera Right",  scene: "camRight", hint: "PTZ · Stage right" },
    { id: "data",  label: "Data Projection", scene: "colorbars", hint: "HDMI · Projector out", isData: true },
  ];
  return (
    <div className="feed-row">
      {cams.map(c => (
        <LiveFeed key={c.id} cam={c} onAir={liveCamId === c.id} onClick={() => setLiveCam(c.id)} />
      ))}
      <OverlayDock overlays={overlays} setOverlays={setOverlays} onTake={onTake}/>
    </div>
  );
}

function LiveFeed({ cam, onAir, onClick }) {
  return (
    <div className={"feed" + (onAir ? " feed-onair" : "")}>
      <div className="feed-head">
        <span className="feed-title">{cam.label}</span>
        {onAir && <span className="feed-live"><span/>LIVE</span>}
        {!onAir && <span className="feed-hint">{cam.hint}</span>}
      </div>
      <button className="feed-img" onClick={onClick}>
        <Thumb scene={cam.scene} />
        {cam.isData && (
          <div className="feed-data-overlay">
            <div className="feed-data-label">SMPTE · 1080p59.94</div>
          </div>
        )}
        {!cam.isData && (
          <div className="feed-fs-hud">
            <span className="hud-ts">11:42:08</span>
            <span className="hud-res">1080p59</span>
          </div>
        )}
      </button>
      {!cam.isData && <PTZPad />}
      {cam.isData && <DataControls />}
    </div>
  );
}

function PTZPad() {
  return (
    <div className="ptzpad">
      <div className="ptzpad-joy" aria-label="Pan/Tilt">
        <div className="joy-ring">
          <button className="joy-arrow joy-tl" aria-label="Pan up-left"><Arrow d="tl"/></button>
          <button className="joy-arrow joy-t"  aria-label="Tilt up"><Arrow d="t"/></button>
          <button className="joy-arrow joy-tr" aria-label="Pan up-right"><Arrow d="tr"/></button>
          <button className="joy-arrow joy-r"  aria-label="Pan right"><Arrow d="r"/></button>
          <button className="joy-arrow joy-br" aria-label="Pan down-right"><Arrow d="br"/></button>
          <button className="joy-arrow joy-b"  aria-label="Tilt down"><Arrow d="b"/></button>
          <button className="joy-arrow joy-bl" aria-label="Pan down-left"><Arrow d="bl"/></button>
          <button className="joy-arrow joy-l"  aria-label="Pan left"><Arrow d="l"/></button>
          <button className="joy-center" aria-label="Home">
            <span className="joy-center-dot" />
            <span className="joy-center-label">HOME</span>
          </button>
        </div>
      </div>
      <div className="ptzpad-controls">
        <div className="ctrl-group">
          <div className="ctrl-label">ZOOM</div>
          <div className="ctrl-pair">
            <button className="ctrl-btn" aria-label="Zoom wide"><ZoomIcon kind="wide"/><em>WIDE</em></button>
            <button className="ctrl-btn" aria-label="Zoom tele"><ZoomIcon kind="tele"/><em>TELE</em></button>
          </div>
        </div>
        <div className="ctrl-group">
          <div className="ctrl-label">FOCUS</div>
          <div className="ctrl-pair">
            <button className="ctrl-btn" aria-label="Focus near"><FocusIcon kind="near"/><em>NEAR</em></button>
            <button className="ctrl-btn" aria-label="Focus far"><FocusIcon kind="far"/><em>FAR</em></button>
          </div>
          <button className="ctrl-auto" aria-label="Auto focus">AUTO</button>
        </div>
      </div>
    </div>
  );
}

function ZoomIcon({ kind }) {
  const w = kind === "tele";
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="6" cy="6" r="4"/>
      <path d="M9 9l3 3"/>
      <path d={w ? "M4 6h4" : "M4 6h4M6 4v4"}/>
    </svg>
  );
}
function FocusIcon({ kind }) {
  const near = kind === "near";
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="7" cy="7" r={near ? 2.5 : 5}/>
      <circle cx="7" cy="7" r="1" fill="currentColor"/>
    </svg>
  );
}

function Arrow({ d }) {
  const rot = { t: 0, tr: 45, r: 90, br: 135, b: 180, bl: 225, l: 270, tl: 315 }[d] || 0;
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" style={{ transform: `rotate(${rot}deg)` }}>
      <path d="M5 1 L9 6 L6.5 6 L6.5 9 L3.5 9 L3.5 6 L1 6 Z" fill="currentColor"/>
    </svg>
  );
}

function DataControls() {
  return (
    <div className="data-ctrls">
      <button className="datbtn on"><span className="dot dot-green"/>Overlay</button>
      <button className="datbtn">Lower Third</button>
      <button className="datbtn">Slides</button>
    </div>
  );
}

function OverlayDock({ overlays, setOverlays, onTake }) {
  return (
    <div className="dock">
      <div className="dock-sec">
        <div className="dock-head">Output Meters</div>
        <Meter label="CHURCH MIX" value={0.62} active />
        <Meter label="VIDEO MIX"  value={0.48} />
        <Meter label="BACKUP"     value={0.08} muted />
        <Meter label="MASTER"     value={0.71} master />
      </div>

      <div className="dock-sec">
        <div className="dock-head">Stream Health</div>
        <HealthRow label="Bitrate"  value="6,240" unit="kbps" good/>
        <HealthRow label="Dropped"  value="0"     unit="frames" good/>
        <HealthRow label="Latency"  value="1.8"   unit="s" good/>
        <HealthRow label="Viewers"  value="1,284" unit="live"/>
        <HealthRow label="CPU"      value="34"    unit="%"/>
      </div>

      <div className="dock-sec dock-take">
        <button className="take-btn" onClick={onTake}>
          <span>TAKE</span>
          <em>Space</em>
        </button>
      </div>
    </div>
  );
}

function Meter({ label, value, active, muted, master }) {
  const pct = Math.min(1, value);
  const segs = 24;
  return (
    <div className={"meter" + (muted ? " muted" : "") + (master ? " master" : "")}>
      <div className="meter-label">
        <span>{label}</span>
        {active && <span className="meter-badge">ACTIVE</span>}
      </div>
      <div className="meter-bar">
        {Array.from({length: segs}).map((_, i) => {
          const on = i / segs < pct;
          const tone = i / segs < 0.6 ? "g" : i / segs < 0.85 ? "y" : "r";
          return <span key={i} className={`seg seg-${tone}` + (on ? " on" : "")}/>;
        })}
      </div>
      <div className="meter-num">{Math.round(-60 + pct * 60)} dB</div>
    </div>
  );
}

function HealthRow({ label, value, unit, good }) {
  return (
    <div className="health">
      <span className="health-label">{label}</span>
      <span className="health-value">
        <b>{value}</b><em>{unit}</em>
        {good && <span className="health-dot"/>}
      </span>
    </div>
  );
}

Object.assign(window, { LiveFeedRow });
